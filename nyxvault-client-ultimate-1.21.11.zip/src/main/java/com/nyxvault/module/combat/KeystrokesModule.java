package com.nyxvault.module.combat;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.module.settings.NumberSetting;
import com.nyxvault.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.LinkedList;

public class KeystrokesModule extends Module {
    private final NumberSetting posX;
    private final NumberSetting posY;
    private final BooleanSetting showMouse;
    private final BooleanSetting showCPS;

    private final LinkedList<Long> leftClicks = new LinkedList<>();
    private final LinkedList<Long> rightClicks = new LinkedList<>();

    public KeystrokesModule() {
        super("Keystrokes", "HUD display of W, A, S, D, mouse clicks, and real-time CPS", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);

        this.posX = new NumberSetting("Pos X", "X coordinate", 20, 0, 1920);
        this.posY = new NumberSetting("Pos Y", "Y coordinate", 20, 0, 1080);
        this.showMouse = new BooleanSetting("Show Mouse", "Display LMB / RMB keys", true);
        this.showCPS = new BooleanSetting("Show CPS", "Display Clicks Per Second", true);

        addSetting(posX);
        addSetting(posY);
        addSetting(showMouse);
        addSetting(showCPS);
    }

    public void registerClick(boolean isLeft) {
        long now = System.currentTimeMillis();
        if (isLeft) leftClicks.add(now);
        else rightClicks.add(now);
    }

    private int getCPS(LinkedList<Long> clicks) {
        long now = System.currentTimeMillis();
        clicks.removeIf(time -> now - time > 1000);
        return clicks.size();
    }

    @Override
    public void onRenderHUD(DrawContext context, float tickDelta) {
        int x = posX.getValue();
        int y = posY.getValue();
        int keySize = 22;
        int gap = 3;

        boolean wPressed = mc.options.forwardKey.isPressed();
        boolean aPressed = mc.options.leftKey.isPressed();
        boolean sPressed = mc.options.backKey.isPressed();
        boolean dPressed = mc.options.rightKey.isPressed();
        boolean lmbPressed = mc.options.attackKey.isPressed();
        boolean rmbPressed = mc.options.useKey.isPressed();

        // Render W
        drawKey(context, "W", x + keySize + gap, y, keySize, keySize, wPressed);
        // Render A, S, D
        drawKey(context, "A", x, y + keySize + gap, keySize, keySize, aPressed);
        drawKey(context, "S", x + keySize + gap, y + keySize + gap, keySize, keySize, sPressed);
        drawKey(context, "D", x + (keySize + gap) * 2, y + keySize + gap, keySize, keySize, dPressed);

        int currentY = y + (keySize + gap) * 2;

        if (showMouse.getValue()) {
            int mouseWidth = (keySize * 3 + gap * 2 - gap) / 2;
            int lmbCPS = getCPS(leftClicks);
            int rmbCPS = getCPS(rightClicks);

            String lmbText = showCPS.getValue() ? "LMB " + lmbCPS : "LMB";
            String rmbText = showCPS.getValue() ? "RMB " + rmbCPS : "RMB";

            drawKey(context, lmbText, x, currentY, mouseWidth, keySize, lmbPressed);
            drawKey(context, rmbText, x + mouseWidth + gap, currentY, mouseWidth, keySize, rmbPressed);

            currentY += keySize + gap;
        }

        // Spacebar
        boolean spacePressed = mc.options.jumpKey.isPressed();
        drawKey(context, "------", x, currentY, keySize * 3 + gap * 2, 14, spacePressed);
    }

    private void drawKey(DrawContext context, String label, int kx, int ky, int kw, int kh, boolean pressed) {
        int bg = pressed ? 0xDD8B5CF6 : 0xAA0B0C18;
        int border = pressed ? 0xFFC084FC : 0x4438BDF8;
        int textColor = pressed ? 0xFFFFFF : 0x94A3B8;

        RenderUtils.drawRoundedRect(context, kx, ky, kw, kh, 4, bg);
        RenderUtils.drawRoundedOutline(context, kx, ky, kw, kh, 4, 1, border);

        int textWidth = mc.textRenderer.getWidth(label);
        context.drawText(mc.textRenderer, label, kx + (kw - textWidth) / 2, ky + (kh - 8) / 2, textColor, true);
    }
}
