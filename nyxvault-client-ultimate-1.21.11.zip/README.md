# NYXVAULT CLIENT ULTIMATE (v1.0.0)

[![Build NYXVAULT CLIENT](https://github.com/nyxvault/nyxvault-client/actions/workflows/build.yml/badge.svg)](https://github.com/nyxvault/nyxvault-client/actions/workflows/build.yml)
[![Minecraft](https://img.shields.io/badge/Minecraft-1.21.1%20%7C%201.21.x-blue.svg)](https://fabricmc.net/)
[![Fabric Loader](https://img.shields.io/badge/Fabric%20Loader-0.16.5-purple.svg)](https://fabricmc.net/)
[![Java](https://img.shields.io/badge/Java-21-orange.svg)](https://adoptium.net/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

Next-generation Minecraft Java Edition client-side mod built on **Fabric 1.21.1** with a futuristic cyberpunk design identity, modular architecture, custom in-game Click GUI, visual HUD editor, and an intelligent waypoint system with automatic removal on arrival.

---

## 1. Compatibility & Verification Notice

- **Minecraft Version:** Minecraft Java Edition **1.21.1** (Official target release for the 1.21.x lifecycle; note that standard Minecraft versioning does not feature an official "1.21.11" release, so this build is engineered for 1.21.1 with support across the 1.21.x range).
- **Fabric Loader:** `>= 0.16.0` (Configured: `0.16.5`)
- **Fabric API:** `0.104.0+1.21.1`
- **Java Virtual Machine:** **Java 21 (LTS)** is strictly required (per Mojang's Minecraft 1.20.5+ / 1.21 runtime transition).
- **Primary Server:** HolyWorld (All modules are client-side only and operate within legitimate client boundaries without packet exploits or anti-cheat bypasses).

---

## 2. Visual Identity & Design System

The NYXVAULT visual identity adheres to a strict high-end cybernetic aesthetic:
- **Deep Black Surfaces:** `#07070d` / `#0a0a14`
- **Midnight-Blue Panels:** `#0f1124` / `#161830`
- **Bright Violet Highlights:** `#8b5cf6` / `#a855f7`
- **Electric-Purple Glow:** `#c084fc`
- **Subtle Cold-Blue Accents:** `#38bdf8` / `#06b6d4`
- **Themes Supported:**
  1. `NYXVAULT SIGNATURE` (Default)
  2. `Dark Purple`
  3. `Cyberpunk Blue`
  4. `Minimal Dark`
  5. `Custom Accent Tinting`

---

## 3. Core Architecture & Features

### In-Game Click GUI (Default Key: `Right Shift`)
- **Categories:**
  1. **Combat:** Hit Marker, Target HUD, Custom Crosshair, Keystrokes, Attack Cooldown.
  2. **Visuals:** Fullbright (reversible gamma backup), Smooth Zoom (interpolated FOV), HUD Tags.
  3. **Movement:** Toggle Sprint, Speedometer, Movement coordinates.
  4. **Player:** Armor status, inventory health, session duration.
  5. **HUD:** Watermark, active module arraylist, ping, FPS counter.
  6. **World:** Waypoint manager, 3D beacon light beams, auto-removal on arrival.
  7. **Utilities:** Configurable AutoClicker (with humanized timing jitter and explicit user hold activation), event alerts.
  8. **Misc:** Session statistics, audio chimes, panic switch.
  9. **Settings:** Profile presets, theme selection, custom accent colors, import/export.

### Section 10: Automatic Waypoint Removal on Arrival
- **Arrival Presets:** `1 block`, `2 blocks`, `3 blocks`, `5 blocks`, `10 blocks`, and `Custom distance`.
- **Modes:** Active-waypoint-only or all reached waypoints.
- **Actions on Arrival:**
  1. Instantly removed from active waypoints collection.
  2. 3D world beacon and radar marker cleared.
  3. Screen distance indicator cleared.
  4. Thread-safe persistence saved to `waypoints.json`.
  5. On-screen **"WAYPOINT REACHED"** banner displayed.
  6. Optional audio chime played.
  7. Strictly disabled by default to prevent accidental data loss.

### HolyWorld Helper Utilities
- Scheduled local event countdowns (30m chest drop cycles, arena tournaments).
- Server status badge and chat highlights for clan/team messages.
- Does **not** scrape unauthorized APIs or forge fake server packets.

---

## 4. How to Build & Produce `nyxvault-client-1.0.0.jar`

### Method A: Automated GitHub Actions CI (Recommended)
1. Push this repository to GitHub or fork it.
2. Navigate to the **Actions** tab on your GitHub repository.
3. The **Build NYXVAULT CLIENT** workflow will execute automatically.
4. Once completed, download the `nyxvault-client-1.0.0.jar` artifact directly from the workflow summary page!

### Method B: Local Command Line Build
Ensure you have **JDK 21** installed (`java -version`).
```bash
# Clone the repository
git clone https://github.com/nyxvault/nyxvault-client.git
cd nyxvault-client

# Make wrapper executable (Linux / macOS)
chmod +x ./gradlew

# Build the Fabric mod JAR
./gradlew build --no-daemon
```
The compiled mod JAR will be located at:
```
build/libs/nyxvault-client-1.0.0.jar
```

---

## 5. Installation Instructions

1. Install [Fabric Loader](https://fabricmc.net/use/installer/) for **Minecraft 1.21.1**.
2. Download [Fabric API](https://modrinth.com/mod/fabric-api) for 1.21.1.
3. Place `fabric-api-*.jar` and `nyxvault-client-1.0.0.jar` into your Minecraft `.minecraft/mods` folder.
4. Launch Minecraft using the Fabric profile.
5. Press **`Right Shift`** in-game to access the NYXVAULT Click GUI!
