package com.nyxvault.module.world;

import com.nyxvault.NyxVaultClient;
import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.module.settings.EnumSetting;
import com.nyxvault.module.settings.NumberSetting;
import org.lwjgl.glfw.GLFW;

public class AutoRemoveWaypointModule extends Module {
    public enum RadiusPreset {
        BLOCK_1("1 Block", 1.0),
        BLOCK_2("2 Blocks", 2.0),
        BLOCK_3("3 Blocks", 3.0),
        BLOCK_5("5 Blocks", 5.0),
        BLOCK_10("10 Blocks", 10.0),
        CUSTOM("Custom Distance", -1.0);

        private final String label;
        private final double distance;
        RadiusPreset(String label, double distance) {
            this.label = label;
            this.distance = distance;
        }
        public double getDistance() { return distance; }
        @Override public String toString() { return label; }
    }

    private final EnumSetting<RadiusPreset> presetSetting;
    private final NumberSetting customRadiusSetting;
    private final BooleanSetting activeOnlySetting;
    private final BooleanSetting notifyArrivalSetting;
    private final BooleanSetting playSoundSetting;

    public AutoRemoveWaypointModule() {
        super("Auto-Remove on Arrival", "Removes waypoint destination when player arrives within configured radius", Category.WORLD, GLFW.GLFW_KEY_UNKNOWN);

        this.presetSetting = new EnumSetting<>("Arrival Preset", "Distance threshold trigger", RadiusPreset.BLOCK_3, RadiusPreset.values());
        this.customRadiusSetting = new NumberSetting("Custom Radius", "Custom block distance trigger", 4, 1, 50);
        this.activeOnlySetting = new BooleanSetting("Active Waypoint Only", "Only remove current navigation target", false);
        this.notifyArrivalSetting = new BooleanSetting("Notify on Arrival", "Show 'WAYPOINT REACHED' banner", true);
        this.playSoundSetting = new BooleanSetting("Arrival Sound", "Play audio chime on arrival", true);

        addSetting(presetSetting);
        addSetting(customRadiusSetting);
        addSetting(activeOnlySetting);
        addSetting(notifyArrivalSetting);
        addSetting(playSoundSetting);

        // Disabled by default as strictly required by section 10
        setEnabled(false);

        presetSetting.setChangeListener(preset -> {
            if (preset.getDistance() > 0) {
                NyxVaultClient.getInstance().getWaypointManager().setDefaultRadius(preset.getDistance());
            } else {
                NyxVaultClient.getInstance().getWaypointManager().setDefaultRadius(customRadiusSetting.getValue());
            }
        });

        customRadiusSetting.setChangeListener(val -> {
            if (presetSetting.getValue() == RadiusPreset.CUSTOM) {
                NyxVaultClient.getInstance().getWaypointManager().setDefaultRadius(val);
            }
        });
    }

    @Override
    public void onEnable() {
        NyxVaultClient.getInstance().getWaypointManager().setGlobalAutoRemove(true);
        double rad = presetSetting.getValue().getDistance() > 0 ? presetSetting.getValue().getDistance() : customRadiusSetting.getValue();
        NyxVaultClient.getInstance().getWaypointManager().setDefaultRadius(rad);
    }

    @Override
    public void onDisable() {
        NyxVaultClient.getInstance().getWaypointManager().setGlobalAutoRemove(false);
    }
}
