package com.nyxvault.theme;

import java.awt.Color;

public class Theme {
    private final String name;
    private final Color primaryBackground;
    private final Color secondaryBackground;
    private final Color cardBackground;
    private final Color accentColor;
    private final Color glowColor;
    private final Color textPrimary;
    private final Color textSecondary;
    private final Color border;

    public Theme(String name, Color primaryBackground, Color secondaryBackground, Color cardBackground,
                 Color accentColor, Color glowColor, Color textPrimary, Color textSecondary, Color border) {
        this.name = name;
        this.primaryBackground = primaryBackground;
        this.secondaryBackground = secondaryBackground;
        this.cardBackground = cardBackground;
        this.accentColor = accentColor;
        this.glowColor = glowColor;
        this.textPrimary = textPrimary;
        this.textSecondary = textSecondary;
        this.border = border;
    }

    public String getName() { return name; }
    public Color getPrimaryBackground() { return primaryBackground; }
    public Color getSecondaryBackground() { return secondaryBackground; }
    public Color getCardBackground() { return cardBackground; }
    public Color getAccentColor() { return accentColor; }
    public Color getGlowColor() { return glowColor; }
    public Color getTextPrimary() { return textPrimary; }
    public Color getTextSecondary() { return textSecondary; }
    public Color getBorder() { return border; }

    public int getAccentHex() { return accentColor.getRGB(); }
    public int getPrimaryBgHex() { return primaryBackground.getRGB(); }
    public int getCardBgHex() { return cardBackground.getRGB(); }
    public int getTextPrimaryHex() { return textPrimary.getRGB(); }
    public int getTextSecondaryHex() { return textSecondary.getRGB(); }
    public int getBorderHex() { return border.getRGB(); }
}
