package com.nyxvault.module;

import com.nyxvault.module.combat.*;
import com.nyxvault.module.hud.HUDEditorModule;
import com.nyxvault.module.movement.ToggleSprintModule;
import com.nyxvault.module.visuals.FullbrightModule;
import com.nyxvault.module.visuals.HUDTagsModule;
import com.nyxvault.module.visuals.SmoothZoomModule;
import com.nyxvault.module.world.AutoRemoveWaypointModule;
import com.nyxvault.module.world.HolyWorldHelperModule;
import com.nyxvault.module.world.WaypointModule;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void registerModules() {
        // Combat
        register(new HitMarkerModule());
        register(new TargetHUDModule());
        register(new CustomCrosshairModule());
        register(new KeystrokesModule());

        // Visuals
        register(new FullbrightModule());
        register(new SmoothZoomModule());
        register(new HUDTagsModule());

        // Movement
        register(new ToggleSprintModule());

        // World
        register(new WaypointModule());
        register(new AutoRemoveWaypointModule());
        register(new HolyWorldHelperModule());

        // Utilities
        register(new AutoClickerModule());

        // HUD
        register(new HUDEditorModule());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> getModulesByCategory(Category category) {
        return modules.stream()
                .filter(m -> m.getCategory() == category)
                .collect(Collectors.toList());
    }

    public Module getModuleByName(String name) {
        return modules.stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        //noinspection unchecked
        return (T) modules.stream()
                .filter(clazz::isInstance)
                .findFirst()
                .orElse(null);
    }

    public void panic() {
        for (Module m : modules) {
            if (m.isEnabled() && m.getCategory() != Category.SETTINGS && m.getCategory() != Category.HUD) {
                m.setEnabled(false);
            }
        }
    }

    public void onTick(MinecraftClient client) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onTick(client);
            }
        }
    }

    public void onRenderHUD(DrawContext context, float tickDelta) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onRenderHUD(context, tickDelta);
            }
        }
    }

    public void onRenderWorld(WorldRenderContext context) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onRenderWorld(context);
            }
        }
    }

    public void handleKeyPress(int keyCode) {
        if (keyCode == 0) return;
        for (Module m : modules) {
            if (m.getKeybind() == keyCode) {
                m.toggle();
            }
        }
    }
}
