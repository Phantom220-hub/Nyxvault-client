package com.nyxvault.module.movement;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class ToggleSprintModule extends Module {
    public ToggleSprintModule() {
        super("Toggle Sprint", "Automatically maintains sprinting while moving forward", Category.MOVEMENT, GLFW.GLFW_KEY_V);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.player.isSneaking() || client.player.horizontalCollision) return;

        // If player is moving forward and has enough hunger, sprint
        if (client.player.input.movementForward > 0.8f && client.player.getHungerManager().getFoodLevel() > 6) {
            client.player.setSprinting(true);
        }
    }
}
