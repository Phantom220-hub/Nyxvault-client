package com.nyxvault.module.visuals;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.DecimalSetting;
import org.lwjgl.glfw.GLFW;

public class FullbrightModule extends Module {
    private final DecimalSetting gammaSetting;
    private double originalGamma = 1.0;

    public FullbrightModule() {
        super("Fullbright", "Enhance ambient lighting in dark caves and night environments", Category.VISUALS, GLFW.GLFW_KEY_B);
        this.gammaSetting = new DecimalSetting("Gamma Boost", "Target gamma multiplier", 12.0, 1.0, 20.0, 0.5);
        addSetting(gammaSetting);
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            this.originalGamma = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(gammaSetting.getValue());
        }
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.getGamma().setValue(originalGamma);
        }
    }
}
