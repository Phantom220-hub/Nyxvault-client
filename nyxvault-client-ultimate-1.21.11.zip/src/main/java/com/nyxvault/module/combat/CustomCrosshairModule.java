package com.nyxvault.module.combat;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.ColorSetting;
import com.nyxvault.module.settings.EnumSetting;
import com.nyxvault.module.settings.NumberSetting;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;

public class CustomCrosshairModule extends Module {
    public enum Style {
        CROSS("Cross"),
        DOT("Dot"),
        CIRCLE("Circle"),
        BRACKETS("Brackets");

        private final String label;
        Style(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    private final EnumSetting<Style> styleSetting;
    private final NumberSetting sizeSetting;
    private final NumberSetting gapSetting;
    private final NumberSetting thicknessSetting;
    private final ColorSetting colorSetting;

    public CustomCrosshairModule() {
        super("Custom Crosshair", "Configurable high-visibility crosshair with custom colors and shapes", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);

        this.styleSetting = new EnumSetting<>("Style", "Crosshair geometry", Style.CROSS, Style.values());
        this.sizeSetting = new NumberSetting("Size", "Line length or radius", 5, 2, 16);
        this.gapSetting = new NumberSetting("Gap", "Center gap distance", 3, 0, 10);
        this.thicknessSetting = new NumberSetting("Thickness", "Line width in pixels", 1, 1, 4);
        this.colorSetting = new ColorSetting("Color", "Crosshair tint", new Color(139, 92, 246));

        addSetting(styleSetting);
        addSetting(sizeSetting);
        addSetting(gapSetting);
        addSetting(thicknessSetting);
        addSetting(colorSetting);
    }

    @Override
    public void onRenderHUD(DrawContext context, float tickDelta) {
        if (mc.getWindow() == null) return;

        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int color = colorSetting.getRGB() | 0xFF000000;
        int s = sizeSetting.getValue();
        int g = gapSetting.getValue();
        int t = thicknessSetting.getValue();

        switch (styleSetting.getValue()) {
            case CROSS -> {
                // Top
                context.fill(cx - t / 2, cy - g - s, cx + (t + 1) / 2, cy - g, color);
                // Bottom
                context.fill(cx - t / 2, cy + g, cx + (t + 1) / 2, cy + g + s, color);
                // Left
                context.fill(cx - g - s, cy - t / 2, cx - g, cy + (t + 1) / 2, color);
                // Right
                context.fill(cx + g, cy - t / 2, cx + g + s, cy + (t + 1) / 2, color);
            }
            case DOT -> {
                context.fill(cx - s, cy - s, cx + s, cy + s, color);
            }
            case CIRCLE -> {
                // Draw 8-point circular border approximation
                context.fill(cx - s, cy - 1, cx + s, cy + 1, color);
                context.fill(cx - 1, cy - s, cx + 1, cy + s, color);
            }
            case BRACKETS -> {
                // Left bracket [
                context.fill(cx - g - 2, cy - s, cx - g, cy + s, color);
                context.fill(cx - g, cy - s, cx - g + 3, cy - s + t, color);
                context.fill(cx - g, cy + s - t, cx - g + 3, cy + s, color);

                // Right bracket ]
                context.fill(cx + g, cy - s, cx + g + 2, cy + s, color);
                context.fill(cx + g - 3, cy - s, cx + g, cy - s + t, color);
                context.fill(cx + g - 3, cy + s - t, cx + g, cy + s, color);
            }
        }
    }
}
