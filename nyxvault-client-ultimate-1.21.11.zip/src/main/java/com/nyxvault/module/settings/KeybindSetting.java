package com.nyxvault.module.settings;

import org.lwjgl.glfw.GLFW;

public class KeybindSetting extends Setting<Integer> {
    public KeybindSetting(String name, String description, int defaultKey) {
        super(name, description, defaultKey);
    }

    public String getKeyName() {
        int key = getValue();
        if (key == GLFW.GLFW_KEY_UNKNOWN || key == 0) return "NONE";
        String name = GLFW.glfwGetKeyName(key, 0);
        if (name != null && !name.isEmpty()) return name.toUpperCase();

        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "R_SHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "L_SHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "L_CTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "R_CTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "L_ALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "R_ALT";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "CAPS";
            case GLFW.GLFW_KEY_F1 -> "F1";
            case GLFW.GLFW_KEY_F2 -> "F2";
            case GLFW.GLFW_KEY_F3 -> "F3";
            case GLFW.GLFW_KEY_F4 -> "F4";
            case GLFW.GLFW_KEY_F5 -> "F5";
            case GLFW.GLFW_KEY_F6 -> "F6";
            case GLFW.GLFW_KEY_F7 -> "F7";
            case GLFW.GLFW_KEY_F8 -> "F8";
            case GLFW.GLFW_KEY_F9 -> "F9";
            case GLFW.GLFW_KEY_F10 -> "F10";
            case GLFW.GLFW_KEY_F11 -> "F11";
            case GLFW.GLFW_KEY_F12 -> "F12";
            default -> "KEY_" + key;
        };
    }
}
