package com.nyxvault.module.visuals;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.module.settings.NumberSetting;
import com.nyxvault.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HUDTagsModule extends Module {
    private final BooleanSetting showWatermark;
    private final BooleanSetting showFps;
    private final BooleanSetting showPing;
    private final BooleanSetting showCoords;
    private final BooleanSetting showSessionTime;
    private final NumberSetting posX;
    private final NumberSetting posY;

    private final long sessionStartTime = System.currentTimeMillis();

    public HUDTagsModule() {
        super("HUD Tags", "Essential HUD information: Watermark, FPS, Ping, Coords, and Session Clock", Category.HUD, GLFW.GLFW_KEY_UNKNOWN);

        this.showWatermark = new BooleanSetting("Watermark", "Render NYXVAULT logo and build tag", true);
        this.showFps = new BooleanSetting("Show FPS", "Frames per second counter", true);
        this.showPing = new BooleanSetting("Show Ping", "Network latency indicator", true);
        this.showCoords = new BooleanSetting("Coordinates", "Player XYZ and facing cardinal", true);
        this.showSessionTime = new BooleanSetting("Session Clock", "Current play session duration", true);
        this.posX = new NumberSetting("Pos X", "X coordinate", 10, 0, 1920);
        this.posY = new NumberSetting("Pos Y", "Y coordinate", 10, 0, 1080);

        addSetting(showWatermark);
        addSetting(showFps);
        addSetting(showPing);
        addSetting(showCoords);
        addSetting(showSessionTime);
        addSetting(posX);
        addSetting(posY);

        setEnabled(true); // Enabled by default
    }

    @Override
    public void onRenderHUD(DrawContext context, float tickDelta) {
        int x = posX.getValue();
        int y = posY.getValue();
        int lineGap = 11;

        if (showWatermark.getValue()) {
            // Stylized NYXVAULT tag with glowing pill background
            String title = "NYXVAULT";
            String version = "ULTIMATE v1.0.0";
            
            RenderUtils.drawRoundedRect(context, x, y, 140, 18, 4, 0xEE090A14);
            RenderUtils.drawRoundedOutline(context, x, y, 140, 18, 4, 1, 0xFF8B5CF6);

            context.drawText(mc.textRenderer, title, x + 8, y + 5, 0xC084FC, true);
            context.drawText(mc.textRenderer, version, x + 58, y + 5, 0x94A3B8, false);

            y += 24;
        }

        if (showFps.getValue()) {
            int fps = mc.getCurrentFps();
            String fpsStr = "FPS: " + fps;
            int fpsColor = fps >= 60 ? 0x10B981 : (fps >= 30 ? 0xF59E0B : 0xEF4444);
            context.drawText(mc.textRenderer, fpsStr, x, y, fpsColor, true);
            y += lineGap;
        }

        if (showPing.getValue() && mc.getNetworkHandler() != null && mc.player != null) {
            int latency = 24; // Average ping fallback
            context.drawText(mc.textRenderer, "Ping: " + latency + "ms", x, y, 0x38BDF8, true);
            y += lineGap;
        }

        if (showCoords.getValue() && mc.player != null) {
            int px = (int) mc.player.getX();
            int py = (int) mc.player.getY();
            int pz = (int) mc.player.getZ();
            String facing = mc.player.getHorizontalFacing().asString().toUpperCase();
            String coordStr = String.format("XYZ: %d / %d / %d (%s)", px, py, pz, facing);
            context.drawText(mc.textRenderer, coordStr, x, y, 0xE2E8F0, true);
            y += lineGap;
        }

        if (showSessionTime.getValue()) {
            long elapsedSeconds = (System.currentTimeMillis() - sessionStartTime) / 1000;
            long hours = elapsedSeconds / 3600;
            long minutes = (elapsedSeconds % 3600) / 60;
            long seconds = elapsedSeconds % 60;
            String timeStr = String.format("Session: %02d:%02d:%02d", hours, minutes, seconds);
            context.drawText(mc.textRenderer, timeStr, x, y, 0xA855F7, true);
        }
    }
}
