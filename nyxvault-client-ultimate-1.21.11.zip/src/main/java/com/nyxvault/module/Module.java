package com.nyxvault.module;

import com.nyxvault.NyxVaultClient;
import com.nyxvault.module.settings.KeybindSetting;
import com.nyxvault.module.settings.Setting;
import com.nyxvault.notification.Notification;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    protected final MinecraftClient mc = MinecraftClient.getInstance();
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private final KeybindSetting keybind;
    private final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, Category category, int defaultKey) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.keybind = new KeybindSetting("Keybind", "Activation key", defaultKey);
        this.settings.add(this.keybind);
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled != enabled) {
            this.enabled = enabled;
            if (enabled) {
                onEnable();
                if (mc.player != null) {
                    NyxVaultClient.getInstance().getNotificationManager().send(new Notification(
                            name,
                            "Module enabled",
                            Notification.Type.INFO,
                            2000
                    ));
                }
            } else {
                onDisable();
                if (mc.player != null) {
                    NyxVaultClient.getInstance().getNotificationManager().send(new Notification(
                            name,
                            "Module disabled",
                            Notification.Type.WARNING,
                            2000
                    ));
                }
            }
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public int getKeybind() {
        return keybind.getValue();
    }

    public void setKeybind(int key) {
        keybind.setValue(key);
    }

    public KeybindSetting getKeybindSetting() {
        return keybind;
    }

    protected void addSetting(Setting<?> setting) {
        this.settings.add(setting);
    }

    public List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    // Lifecycle methods
    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient client) {}
    public void onRenderHUD(DrawContext context, float tickDelta) {}
    public void onRenderWorld(WorldRenderContext context) {}
}
