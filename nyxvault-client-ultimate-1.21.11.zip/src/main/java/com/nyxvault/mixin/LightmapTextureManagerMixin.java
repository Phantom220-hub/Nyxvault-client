package com.nyxvault.mixin;

import com.nyxvault.NyxVaultClient;
import com.nyxvault.module.visuals.FullbrightModule;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerMixin {

    @ModifyVariable(method = "update", at = @At("STORE"), ordinal = 6)
    private float modifyGamma(float original) {
        if (NyxVaultClient.getInstance() != null) {
            FullbrightModule fullbright = NyxVaultClient.getInstance().getModuleManager().getModule(FullbrightModule.class);
            if (fullbright != null && fullbright.isEnabled()) {
                return 15.0f; // Max visual illumination without packet changes
            }
        }
        return original;
    }
}
