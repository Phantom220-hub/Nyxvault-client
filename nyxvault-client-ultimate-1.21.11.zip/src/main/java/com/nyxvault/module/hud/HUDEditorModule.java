package com.nyxvault.module.hud;

import com.nyxvault.gui.HUDEditorScreen;
import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import org.lwjgl.glfw.GLFW;

public class HUDEditorModule extends Module {
    public HUDEditorModule() {
        super("HUD Editor", "Open the visual drag-and-drop interface editor for on-screen widgets", Category.HUD, GLFW.GLFW_KEY_R);
    }

    @Override
    public void onEnable() {
        if (mc.currentScreen == null) {
            mc.setScreen(new HUDEditorScreen());
        }
        // Immediately reset state so it acts as an action trigger
        setEnabled(false);
    }
}
