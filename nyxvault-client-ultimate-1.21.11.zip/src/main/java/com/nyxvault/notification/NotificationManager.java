package com.nyxvault.notification;

import com.nyxvault.render.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.concurrent.CopyOnWriteArrayList;

public class NotificationManager {
    private final CopyOnWriteArrayList<Notification> notifications = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<Notification> history = new CopyOnWriteArrayList<>();

    public void send(Notification notification) {
        notifications.add(notification);
        history.add(notification);
        if (history.size() > 50) {
            history.remove(0);
        }
    }

    public void onTick() {
        notifications.removeIf(Notification::isExpired);
    }

    public void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (notifications.isEmpty() || client.getWindow() == null) return;

        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();

        int yOffset = screenHeight - 40;
        int cardWidth = 190;
        int cardHeight = 34;

        for (int i = notifications.size() - 1; i >= 0; i--) {
            Notification n = notifications.get(i);
            float progress = n.getProgress();
            
            // Slide animation
            float slide = 1.0f;
            if (progress < 0.15f) {
                slide = progress / 0.15f;
            } else if (progress > 0.85f) {
                slide = (1.0f - progress) / 0.15f;
            }
            int x = (int) (screenWidth - (cardWidth + 12) * slide);

            // Draw Card Background
            RenderUtils.drawRoundedRect(context, x, yOffset, cardWidth, cardHeight, 6, 0xEE0B0C18);
            RenderUtils.drawRoundedOutline(context, x, yOffset, cardWidth, cardHeight, 6, 1, n.getType().getColor());

            // Type Indicator bar
            RenderUtils.drawRoundedRect(context, x + 2, yOffset + 2, 4, cardHeight - 4, 2, n.getType().getColor());

            // Notification Text
            context.drawText(client.textRenderer, n.getTitle(), x + 12, yOffset + 6, 0xFFFFFF, true);
            context.drawText(client.textRenderer, n.getMessage(), x + 12, yOffset + 18, 0x94A3B8, false);

            yOffset -= (cardHeight + 6);
        }
    }

    public CopyOnWriteArrayList<Notification> getHistory() {
        return history;
    }
}
