package com.nyxvault.module;

public enum Category {
    COMBAT("Combat", "PvP enhancements, attack indicators, hit markers, and targeting"),
    VISUALS("Visuals", "Rendering modifications, fullbright, zoom, and atmosphere"),
    MOVEMENT("Movement", "Sprint toggle, movement HUD, coordinates, and navigation"),
    PLAYER("Player", "Inventory indicators, armor condition, and local stats"),
    HUD("HUD", "Heads-up display tags, watermark, keystrokes, and customization"),
    WORLD("World", "Waypoints, 3D beams, auto-removal on arrival, and markers"),
    UTILITIES("Utilities", "AutoClicker, event notifiers, timers, and game helpers"),
    MISC("Misc", "Session statistics, sound effects, and diagnostic tools"),
    SETTINGS("Settings", "Client customization, themes, profiles, and keybinds");

    private final String displayName;
    private final String description;

    Category(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }
}
