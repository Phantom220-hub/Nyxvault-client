package com.nyxvault.render;

import net.minecraft.client.gui.DrawContext;

public class RenderUtils {

    /**
     * Draws a filled rounded rectangle onto the Minecraft DrawContext.
     */
    public static void drawRoundedRect(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        // Center rectangle
        context.fill(x + radius, y, x + width - radius, y + height, color);
        // Left rectangle
        context.fill(x, y + radius, x + radius, y + height - radius, color);
        // Right rectangle
        context.fill(x + width - radius, y + radius, x + width, y + height - radius, color);

        // Approximate corners
        context.fill(x + 1, y + 1, x + radius, y + radius, color);
        context.fill(x + width - radius, y + 1, x + width - 1, y + radius, color);
        context.fill(x + 1, y + height - radius, x + radius, y + height - 1, color);
        context.fill(x + width - radius, y + height - radius, x + width - 1, y + height - 1, color);
    }

    /**
     * Draws a rounded outline with custom thickness.
     */
    public static void drawRoundedOutline(DrawContext context, int x, int y, int width, int height, int radius, int thickness, int color) {
        // Top and bottom borders
        context.fill(x + radius, y, x + width - radius, y + thickness, color);
        context.fill(x + radius, y + height - thickness, x + width - radius, y + height, color);
        // Left and right borders
        context.fill(x, y + radius, x + thickness, y + height - radius, color);
        context.fill(x + width - thickness, y + radius, x + width, y + height - radius, color);
    }

    /**
     * Draws a gradient rectangle.
     */
    public static void drawGradientRect(DrawContext context, int x, int y, int width, int height, int startColor, int endColor) {
        context.fillGradient(x, y, x + width, y + height, startColor, endColor);
    }

    /**
     * Linear interpolation helper.
     */
    public static float lerp(float start, float end, float delta) {
        return start + delta * (end - start);
    }
}
