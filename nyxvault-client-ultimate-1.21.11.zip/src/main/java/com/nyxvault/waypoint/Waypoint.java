package com.nyxvault.waypoint;

import java.util.UUID;

public class Waypoint {
    private final String id;
    private String name;
    private String description;
    private double x;
    private double y;
    private double z;
    private String dimension;
    private int colorHex;
    private String icon;
    private String group;
    private boolean enabled;
    private boolean autoRemove;
    private double arrivalRadius; // blocks: 1, 2, 3, 5, 10, or custom

    public Waypoint(String name, String description, double x, double y, double z, String dimension, int colorHex, String icon, String group) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.description = description;
        this.x = x;
        this.y = y;
        this.z = z;
        this.dimension = dimension;
        this.colorHex = colorHex;
        this.icon = icon != null ? icon : "STAR";
        this.group = group != null ? group : "Default";
        this.enabled = true;
        this.autoRemove = false;
        this.arrivalRadius = 3.0; // Default 3 blocks
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getX() { return x; }
    public void setX(double x) { this.x = x; }

    public double getY() { return y; }
    public void setY(double y) { this.y = y; }

    public double getZ() { return z; }
    public void setZ(double z) { this.z = z; }

    public String getDimension() { return dimension; }
    public void setDimension(String dimension) { this.dimension = dimension; }

    public int getColorHex() { return colorHex; }
    public void setColorHex(int colorHex) { this.colorHex = colorHex; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getGroup() { return group; }
    public void setGroup(String group) { this.group = group; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public boolean isAutoRemove() { return autoRemove; }
    public void setAutoRemove(boolean autoRemove) { this.autoRemove = autoRemove; }

    public double getArrivalRadius() { return arrivalRadius; }
    public void setArrivalRadius(double arrivalRadius) { this.arrivalRadius = arrivalRadius; }

    public double distanceTo(double px, double py, double pz) {
        double dx = this.x - px;
        double dy = this.y - py;
        double dz = this.z - pz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
