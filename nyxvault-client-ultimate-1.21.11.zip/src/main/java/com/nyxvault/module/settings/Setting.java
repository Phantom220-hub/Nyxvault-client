package com.nyxvault.module.settings;

import java.util.function.Consumer;

public abstract class Setting<T> {
    private final String name;
    private final String description;
    private T value;
    private final T defaultValue;
    private Consumer<T> changeListener;

    public Setting(String name, String description, T defaultValue) {
        this.name = name;
        this.description = description;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
        if (changeListener != null) {
            changeListener.accept(value);
        }
    }

    public T getDefaultValue() {
        return defaultValue;
    }

    public void reset() {
        setValue(defaultValue);
    }

    public void setChangeListener(Consumer<T> listener) {
        this.changeListener = listener;
    }
}
