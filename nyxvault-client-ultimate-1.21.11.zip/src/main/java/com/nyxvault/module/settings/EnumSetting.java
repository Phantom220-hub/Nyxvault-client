package com.nyxvault.module.settings;

public class EnumSetting<E extends Enum<E>> extends Setting<E> {
    private final E[] values;

    public EnumSetting(String name, String description, E defaultValue, E[] values) {
        super(name, description, defaultValue);
        this.values = values;
    }

    public E[] getValues() {
        return values;
    }

    public void cycleNext() {
        int nextIndex = (getValue().ordinal() + 1) % values.length;
        setValue(values[nextIndex]);
    }
}
