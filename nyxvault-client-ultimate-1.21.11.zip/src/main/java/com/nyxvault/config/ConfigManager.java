package com.nyxvault.config;

import com.google.gson.*;
import com.nyxvault.NyxVaultClient;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.Setting;
import com.nyxvault.waypoint.Waypoint;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Path;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final File configFile;
    private final File waypointsFile;

    public ConfigManager() {
        Path configDir = FabricLoader.getInstance().getConfigDir().resolve("nyxvault");
        File dir = configDir.toFile();
        if (!dir.exists()) {
            dir.mkdirs();
        }
        this.configFile = new File(dir, "config.json");
        this.waypointsFile = new File(dir, "waypoints.json");
    }

    public synchronized void saveConfig() {
        try {
            JsonObject root = new JsonObject();

            // 1. Save Modules & Settings
            JsonObject modulesObj = new JsonObject();
            for (Module m : NyxVaultClient.getInstance().getModuleManager().getModules()) {
                JsonObject modObj = new JsonObject();
                modObj.addProperty("enabled", m.isEnabled());
                modObj.addProperty("keybind", m.getKeybind());

                JsonObject settingsObj = new JsonObject();
                for (Setting<?> s : m.getSettings()) {
                    settingsObj.addProperty(s.getName(), s.getValue().toString());
                }
                modObj.add("settings", settingsObj);
                modulesObj.add(m.getName(), modObj);
            }
            root.add("modules", modulesObj);

            // 2. Save Active Theme
            root.addProperty("theme", NyxVaultClient.getInstance().getThemeManager().getCurrentTheme().getName());

            try (FileWriter writer = new FileWriter(configFile)) {
                GSON.toJson(root, writer);
            }

            // 3. Save Waypoints
            JsonArray waypointsArray = new JsonArray();
            for (Waypoint wp : NyxVaultClient.getInstance().getWaypointManager().getWaypoints()) {
                JsonObject wpObj = new JsonObject();
                wpObj.addProperty("name", wp.getName());
                wpObj.addProperty("description", wp.getDescription());
                wpObj.addProperty("x", wp.getX());
                wpObj.addProperty("y", wp.getY());
                wpObj.addProperty("z", wp.getZ());
                wpObj.addProperty("dimension", wp.getDimension());
                wpObj.addProperty("colorHex", wp.getColorHex());
                wpObj.addProperty("icon", wp.getIcon());
                wpObj.addProperty("group", wp.getGroup());
                wpObj.addProperty("enabled", wp.isEnabled());
                wpObj.addProperty("autoRemove", wp.isAutoRemove());
                wpObj.addProperty("arrivalRadius", wp.getArrivalRadius());
                waypointsArray.add(wpObj);
            }

            try (FileWriter writer = new FileWriter(waypointsFile)) {
                GSON.toJson(waypointsArray, writer);
            }
        } catch (Exception e) {
            NyxVaultClient.LOGGER.error("Failed to save NYXVAULT configuration: ", e);
        }
    }

    public synchronized void loadConfig() {
        if (configFile.exists()) {
            try (FileReader reader = new FileReader(configFile)) {
                JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();

                if (root.has("theme")) {
                    NyxVaultClient.getInstance().getThemeManager().setTheme(root.get("theme").getAsString());
                }

                if (root.has("modules")) {
                    JsonObject modulesObj = root.getAsJsonObject("modules");
                    for (Module m : NyxVaultClient.getInstance().getModuleManager().getModules()) {
                        if (modulesObj.has(m.getName())) {
                            JsonObject modObj = modulesObj.getAsJsonObject(m.getName());
                            if (modObj.has("enabled")) {
                                m.setEnabled(modObj.get("enabled").getAsBoolean());
                            }
                            if (modObj.has("keybind")) {
                                m.setKeybind(modObj.get("keybind").getAsInt());
                            }
                        }
                    }
                }
            } catch (Exception e) {
                NyxVaultClient.LOGGER.error("Failed to load NYXVAULT configuration: ", e);
            }
        }
    }
}
