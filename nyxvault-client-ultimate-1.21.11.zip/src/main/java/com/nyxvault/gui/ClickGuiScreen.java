package com.nyxvault.gui;

import com.nyxvault.NyxVaultClient;
import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.module.settings.NumberSetting;
import com.nyxvault.module.settings.Setting;
import com.nyxvault.render.RenderUtils;
import com.nyxvault.theme.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.stream.Collectors;

public class ClickGuiScreen extends Screen {
    private Category currentCategory = Category.COMBAT;
    private String searchQuery = "";
    private Module expandedModule = null;

    private int guiX;
    private int guiY;
    private final int guiWidth = 580;
    private final int guiHeight = 380;
    private final int sidebarWidth = 140;

    public ClickGuiScreen() {
        super(Text.literal("NYXVAULT CLIENT CLICK GUI"));
    }

    @Override
    protected void init() {
        this.guiX = (this.width - guiWidth) / 2;
        this.guiY = (this.height - guiHeight) / 2;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dark translucent blurred backdrop
        context.fill(0, 0, this.width, this.height, 0x88040408);

        Theme theme = NyxVaultClient.getInstance().getThemeManager().getCurrentTheme();

        // Main Container Card
        RenderUtils.drawRoundedRect(context, guiX, guiY, guiWidth, guiHeight, 8, theme.getPrimaryBgHex());
        RenderUtils.drawRoundedOutline(context, guiX, guiY, guiWidth, guiHeight, 8, 1, theme.getBorderHex());

        // Sidebar Background
        RenderUtils.drawRoundedRect(context, guiX, guiY, sidebarWidth, guiHeight, 8, theme.getSecondaryBgHex());

        // NYXVAULT Brand Header
        context.drawText(this.textRenderer, "NYXVAULT", guiX + 16, guiY + 16, theme.getAccentHex(), true);
        context.drawText(this.textRenderer, "v1.0.0", guiX + 78, guiY + 16, theme.getTextSecondaryHex(), false);

        // Sidebar Category Buttons
        int catY = guiY + 44;
        for (Category cat : Category.values()) {
            boolean isSelected = (cat == currentCategory && searchQuery.isEmpty());
            boolean isHovered = mouseX >= guiX + 8 && mouseX <= guiX + sidebarWidth - 8 && mouseY >= catY && mouseY <= catY + 24;

            int btnBg = isSelected ? 0xDD2A1B4E : (isHovered ? 0x442A1B4E : 0x00000000);
            int textColor = isSelected ? theme.getAccentHex() : (isHovered ? 0xFFFFFF : theme.getTextSecondaryHex());

            if (isSelected) {
                RenderUtils.drawRoundedRect(context, guiX + 8, catY, sidebarWidth - 16, 24, 4, btnBg);
                RenderUtils.drawRoundedRect(context, guiX + 8, catY + 4, 3, 16, 1, theme.getAccentHex());
            }

            context.drawText(this.textRenderer, cat.getDisplayName(), guiX + 18, catY + 8, textColor, isSelected);
            catY += 28;
        }

        // Main Content Area
        int contentX = guiX + sidebarWidth + 14;
        int contentY = guiY + 16;
        int contentW = guiWidth - sidebarWidth - 28;

        // Search Bar
        RenderUtils.drawRoundedRect(context, contentX, contentY, contentW, 26, 4, 0xEE111222);
        RenderUtils.drawRoundedOutline(context, contentX, contentY, contentW, 26, 4, 1, 0x448B5CF6);
        String searchDisplay = searchQuery.isEmpty() ? "Search modules..." : searchQuery;
        int searchColor = searchQuery.isEmpty() ? 0x64748B : 0xFFFFFF;
        context.drawText(this.textRenderer, searchDisplay, contentX + 10, contentY + 9, searchColor, false);

        // Filter modules by category or search query
        List<Module> visibleModules = NyxVaultClient.getInstance().getModuleManager().getModules().stream()
                .filter(m -> searchQuery.isEmpty() ? m.getCategory() == currentCategory : m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
                .collect(Collectors.toList());

        // Module Cards Grid
        int cardY = contentY + 36;
        for (Module mod : visibleModules) {
            boolean isHovered = mouseX >= contentX && mouseX <= contentX + contentW && mouseY >= cardY && mouseY <= cardY + 42;
            int cardBg = mod.isEnabled() ? 0xDD181B34 : (isHovered ? 0xDD14162B : 0xCC0E1020);
            int cardBorder = mod.isEnabled() ? theme.getAccentHex() : 0x3338BDF8;

            RenderUtils.drawRoundedRect(context, contentX, cardY, contentW, 42, 6, cardBg);
            RenderUtils.drawRoundedOutline(context, contentX, cardY, contentW, 42, 6, 1, cardBorder);

            // Module Name & Description
            context.drawText(this.textRenderer, mod.getName(), contentX + 12, cardY + 8, 0xFFFFFF, true);
            context.drawText(this.textRenderer, mod.getDescription(), contentX + 12, cardY + 22, theme.getTextSecondaryHex(), false);

            // Keybind Badge
            String keyStr = "[" + mod.getKeybindSetting().getKeyName() + "]";
            int keyW = this.textRenderer.getWidth(keyStr);
            context.drawText(this.textRenderer, keyStr, contentX + contentW - keyW - 48, cardY + 16, 0x94A3B8, false);

            // Toggle Switch
            int switchX = contentX + contentW - 36;
            int switchY = cardY + 13;
            int switchBg = mod.isEnabled() ? theme.getAccentHex() : 0xFF334155;
            RenderUtils.drawRoundedRect(context, switchX, switchY, 26, 14, 7, switchBg);
            int knobX = mod.isEnabled() ? switchX + 14 : switchX + 2;
            RenderUtils.drawRoundedRect(context, knobX, switchY + 2, 10, 10, 5, 0xFFFFFFFF);

            cardY += 48;
            if (cardY > guiY + guiHeight - 50) break;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            // Category navigation click
            int catY = guiY + 44;
            for (Category cat : Category.values()) {
                if (mouseX >= guiX + 8 && mouseX <= guiX + sidebarWidth - 8 && mouseY >= catY && mouseY <= catY + 24) {
                    this.currentCategory = cat;
                    this.searchQuery = "";
                    return true;
                }
                catY += 28;
            }

            // Module card toggle click
            int contentX = guiX + sidebarWidth + 14;
            int contentW = guiWidth - sidebarWidth - 28;
            int cardY = guiY + 52;

            List<Module> visibleModules = NyxVaultClient.getInstance().getModuleManager().getModules().stream()
                    .filter(m -> searchQuery.isEmpty() ? m.getCategory() == currentCategory : m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
                    .collect(Collectors.toList());

            for (Module mod : visibleModules) {
                if (mouseX >= contentX && mouseX <= contentX + contentW && mouseY >= cardY && mouseY <= cardY + 42) {
                    mod.toggle();
                    NyxVaultClient.getInstance().getConfigManager().saveConfig();
                    return true;
                }
                cardY += 48;
                if (cardY > guiY + guiHeight - 50) break;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
