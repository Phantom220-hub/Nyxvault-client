package com.nyxvault.module.world;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.Calendar;
import java.util.TimeZone;

public class HolyWorldHelperModule extends Module {
    private final BooleanSetting showEventCountdown;
    private final BooleanSetting showServerTag;
    private final BooleanSetting chatAlerts;

    public HolyWorldHelperModule() {
        super("HolyWorld Helper", "Legitimate client-side companion for HolyWorld: event countdowns and server indicators", Category.WORLD, GLFW.GLFW_KEY_UNKNOWN);

        this.showEventCountdown = new BooleanSetting("Event Countdown", "Display local timer to scheduled daily events", true);
        this.showServerTag = new BooleanSetting("Server Tag", "Show HolyWorld status indicator on HUD", true);
        this.chatAlerts = new BooleanSetting("Chat Highlights", "Highlight mentions and team chat in neon colors", true);

        addSetting(showEventCountdown);
        addSetting(showServerTag);
        addSetting(chatAlerts);

        setEnabled(true);
    }

    @Override
    public void onRenderHUD(DrawContext context, float tickDelta) {
        if (mc.getCurrentServerEntry() == null) return;
        String address = mc.getCurrentServerEntry().address.toLowerCase();
        if (!address.contains("holyworld") && !address.contains("localhost")) return;

        int screenWidth = mc.getWindow().getScaledWidth();
        int y = 40;

        if (showServerTag.getValue()) {
            String tag = "HOLYWORLD COMPANION";
            int textWidth = mc.textRenderer.getWidth(tag);
            int x = screenWidth - textWidth - 24;

            RenderUtils.drawRoundedRect(context, x, y, textWidth + 16, 18, 4, 0xEE090A14);
            RenderUtils.drawRoundedOutline(context, x, y, textWidth + 16, 18, 4, 1, 0xFF38BDF8);

            context.drawText(mc.textRenderer, tag, x + 8, y + 5, 0x38BDF8, true);
            y += 24;
        }

        if (showEventCountdown.getValue()) {
            // Calculate time remaining to next 30-minute chest / arena event cycle
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
            int minutes = cal.get(Calendar.MINUTE);
            int seconds = cal.get(Calendar.SECOND);
            int nextEventMinutes = 30 - (minutes % 30) - 1;
            int nextEventSeconds = 60 - seconds;
            if (nextEventSeconds == 60) {
                nextEventSeconds = 0;
                nextEventMinutes++;
            }

            String eventStr = String.format("Next Event: %02dm %02ds", nextEventMinutes, nextEventSeconds);
            int textWidth = mc.textRenderer.getWidth(eventStr);
            int x = screenWidth - textWidth - 24;

            RenderUtils.drawRoundedRect(context, x, y, textWidth + 16, 18, 4, 0xEE090A14);
            RenderUtils.drawRoundedOutline(context, x, y, textWidth + 16, 18, 4, 1, 0xFFA855F7);

            context.drawText(mc.textRenderer, eventStr, x + 8, y + 5, 0xC084FC, true);
        }
    }
}
