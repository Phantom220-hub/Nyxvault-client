package com.nyxvault.gui;

import com.nyxvault.NyxVaultClient;
import com.nyxvault.notification.Notification;
import com.nyxvault.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class HUDEditorScreen extends Screen {
    private boolean isDragging = false;
    private int dragTarget = 0; // 1: Keystrokes, 2: TargetHUD, 3: HUDTags
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;

    public HUDEditorScreen() {
        super(Text.literal("NYXVAULT HUD EDITOR"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Translucent grid overlay
        context.fill(0, 0, this.width, this.height, 0x5505050A);

        // Grid lines (every 20px)
        for (int x = 0; x < this.width; x += 40) {
            context.fill(x, 0, x + 1, this.height, 0x1538BDF8);
        }
        for (int y = 0; y < this.height; y += 40) {
            context.fill(0, y, this.width, y + 1, 0x1538BDF8);
        }

        // Top info bar
        int barW = 260;
        int barX = (this.width - barW) / 2;
        RenderUtils.drawRoundedRect(context, barX, 10, barW, 26, 4, 0xEE090A14);
        RenderUtils.drawRoundedOutline(context, barX, 10, barW, 26, 4, 1, 0xFF8B5CF6);
        context.drawText(this.textRenderer, "HUD EDITOR - Drag Elements - [ESC] to Save", barX + 12, 19, 0xFFFFFF, true);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (isDragging) {
            isDragging = false;
            NyxVaultClient.getInstance().getConfigManager().saveConfig();
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        NyxVaultClient.getInstance().getConfigManager().saveConfig();
        NyxVaultClient.getInstance().getNotificationManager().send(new Notification("HUD SAVED", "Widget positions updated successfully", Notification.Type.SUCCESS, 2500));
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
