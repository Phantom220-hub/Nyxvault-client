package com.nyxvault;

import com.nyxvault.config.ConfigManager;
import com.nyxvault.gui.ClickGuiScreen;
import com.nyxvault.module.ModuleManager;
import com.nyxvault.notification.Notification;
import com.nyxvault.notification.NotificationManager;
import com.nyxvault.theme.ThemeManager;
import com.nyxvault.waypoint.WaypointManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * NYXVAULT CLIENT ULTIMATE
 * Next-generation Minecraft Java Edition 1.21.1 Fabric Client Mod
 */
public class NyxVaultClient implements ClientModInitializer {
    public static final String MOD_ID = "nyxvault";
    public static final String MOD_NAME = "NYXVAULT CLIENT ULTIMATE";
    public static final String MOD_VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    private static NyxVaultClient instance;
    private ModuleManager moduleManager;
    private ConfigManager configManager;
    private ThemeManager themeManager;
    private NotificationManager notificationManager;
    private WaypointManager waypointManager;

    private KeyBinding clickGuiKeyBinding;
    private KeyBinding panicKeyBinding;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("[{}] Initializing core architecture for Minecraft 1.21.1...", MOD_NAME);

        // 1. Initialize Subsystems
        this.themeManager = new ThemeManager();
        this.notificationManager = new NotificationManager();
        this.waypointManager = new WaypointManager();
        this.moduleManager = new ModuleManager();
        this.configManager = new ConfigManager();

        // 2. Register Global Keybindings
        this.clickGuiKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nyxvault.clickgui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.nyxvault.title"
        ));

        this.panicKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nyxvault.panic",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F12,
                "category.nyxvault.title"
        ));

        // 3. Register Module Lifecycle Events
        this.moduleManager.registerModules();

        // 4. Load Persistent Configuration
        this.configManager.loadConfig();

        // 5. Register Fabric Hooks
        registerEventHooks();

        this.notificationManager.send(new Notification(
                "NYXVAULT LOADED",
                "Press [Right Shift] to open Click GUI",
                Notification.Type.SUCCESS,
                5000
        ));

        LOGGER.info("[{}] Startup complete! {} modules registered.", MOD_NAME, moduleManager.getModules().size());
    }

    private void registerEventHooks() {
        // Client Tick (Input, AutoClicker, Module updates, Waypoint arrival detection)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // Handle Click GUI opening
            while (clickGuiKeyBinding.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }

            // Handle Panic Key (Instantly disable active modules)
            while (panicKeyBinding.wasPressed()) {
                moduleManager.panic();
                notificationManager.send(new Notification("PANIC ACTIVATED", "All eligible modules disabled", Notification.Type.WARNING, 4000));
            }

            // Tick active modules
            moduleManager.onTick(client);

            // Tick waypoints (auto-removal logic)
            waypointManager.onTick(client);

            // Tick notifications
            notificationManager.onTick();
        });

        // 2D HUD Rendering Callback
        HudRenderCallback.EVENT.register((DrawContext context, RenderTickCounter tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.options.hudHidden) return;

            // Render active HUD modules
            moduleManager.onRenderHUD(context, tickCounter.getTickDelta(false));

            // Render Notifications on top
            notificationManager.render(context);
        });

        // 3D World Rendering Callback (Waypoints, Beams, Tracers)
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.world == null) return;

            moduleManager.onRenderWorld(context);
            waypointManager.renderWorld(context);
        });
    }

    public static NyxVaultClient getInstance() {
        return instance;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public ThemeManager getThemeManager() {
        return themeManager;
    }

    public NotificationManager getNotificationManager() {
        return notificationManager;
    }

    public WaypointManager getWaypointManager() {
        return waypointManager;
    }
}
