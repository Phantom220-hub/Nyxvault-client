package com.nyxvault.module.world;

import com.nyxvault.NyxVaultClient;
import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.module.settings.NumberSetting;
import com.nyxvault.render.RenderUtils;
import com.nyxvault.waypoint.Waypoint;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class WaypointModule extends Module {
    private final BooleanSetting renderBeams;
    private final BooleanSetting showDistanceHUD;
    private final NumberSetting maxRenderDistance;

    public WaypointModule() {
        super("Waypoints", "World beacon markers, 3D beams, and active navigation distance HUD", Category.WORLD, GLFW.GLFW_KEY_H);

        this.renderBeams = new BooleanSetting("Render Beams", "Draw vertical 3D light pillars", true);
        this.showDistanceHUD = new BooleanSetting("Distance HUD", "Show distance to active waypoint on screen", true);
        this.maxRenderDistance = new NumberSetting("Render Range", "Max block radius to render waypoints", 5000, 100, 10000);

        addSetting(renderBeams);
        addSetting(showDistanceHUD);
        addSetting(maxRenderDistance);

        setEnabled(true);
    }

    @Override
    public void onRenderHUD(DrawContext context, float tickDelta) {
        if (!showDistanceHUD.getValue() || mc.player == null) return;

        Waypoint active = NyxVaultClient.getInstance().getWaypointManager().getActiveWaypoint();
        if (active == null || !active.isEnabled()) return;

        double dist = active.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        String info = String.format("%s: %.0fm (%d, %d, %d)", active.getName(), dist, (int) active.getX(), (int) active.getY(), (int) active.getZ());

        int screenWidth = mc.getWindow().getScaledWidth();
        int width = mc.textRenderer.getWidth(info) + 16;
        int x = (screenWidth - width) / 2;
        int y = 14;

        RenderUtils.drawRoundedRect(context, x, y, width, 18, 4, 0xEE090A14);
        RenderUtils.drawRoundedOutline(context, x, y, width, 18, 4, 1, active.getColorHex());

        context.drawText(mc.textRenderer, info, x + 8, y + 5, 0xFFFFFF, true);
    }
}
