package com.nyxvault.module.combat;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.module.settings.NumberSetting;
import com.nyxvault.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import org.lwjgl.glfw.GLFW;

public class TargetHUDModule extends Module {
    private final NumberSetting posX;
    private final NumberSetting posY;
    private final BooleanSetting showArmor;
    private final BooleanSetting showDistance;

    private LivingEntity currentTarget;
    private float animatedHealth = 20.0f;

    public TargetHUDModule() {
        super("Target HUD", "Futuristic HUD card displaying targeted entity stats and health bar", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);

        this.posX = new NumberSetting("Position X", "Horizontal offset", 350, 0, 1920);
        this.posY = new NumberSetting("Position Y", "Vertical offset", 220, 0, 1080);
        this.showArmor = new BooleanSetting("Show Armor", "Display target's equipped armor durability", true);
        this.showDistance = new BooleanSetting("Show Distance", "Display distance in blocks to target", true);

        addSetting(posX);
        addSetting(posY);
        addSetting(showArmor);
        addSetting(showDistance);
    }

    public void setTarget(LivingEntity entity) {
        this.currentTarget = entity;
    }

    @Override
    public void onRenderHUD(DrawContext context, float tickDelta) {
        if (currentTarget == null || !currentTarget.isAlive()) return;

        int x = posX.getValue();
        int y = posY.getValue();
        int width = 150;
        int height = 48;

        float targetHealth = currentTarget.getHealth();
        float maxHealth = currentTarget.getMaxHealth();
        animatedHealth = RenderUtils.lerp(animatedHealth, targetHealth, tickDelta * 0.2f);

        // Card background
        RenderUtils.drawRoundedRect(context, x, y, width, height, 6, 0xEE0B0C18);
        RenderUtils.drawRoundedOutline(context, x, y, width, height, 6, 1, 0x8B5CF6);

        // Name
        String name = currentTarget.getName().getString();
        context.drawText(mc.textRenderer, name, x + 8, y + 8, 0xFFFFFF, true);

        // Distance
        if (showDistance.getValue() && mc.player != null) {
            double dist = mc.player.distanceTo(currentTarget);
            String distStr = String.format("%.1fm", dist);
            context.drawText(mc.textRenderer, distStr, x + width - mc.textRenderer.getWidth(distStr) - 8, y + 8, 0x38BDF8, false);
        }

        // Health Bar
        int barX = x + 8;
        int barY = y + 26;
        int barW = width - 16;
        int barH = 6;

        // Background
        context.fill(barX, barY, barX + barW, barY + barH, 0xFF1E1E2E);

        // Filled
        float healthPct = Math.max(0f, Math.min(1f, animatedHealth / maxHealth));
        int fillW = (int) (barW * healthPct);
        int barColor = healthPct > 0.5f ? 0xFF8B5CF6 : (healthPct > 0.25f ? 0xFFF59E0B : 0xFFEF4444);
        context.fill(barX, barY, barX + fillW, barY + barH, barColor);

        // HP Text
        String hpStr = String.format("%.1f HP", animatedHealth);
        context.drawText(mc.textRenderer, hpStr, x + 8, y + 35, 0x94A3B8, false);
    }
}
