package com.nyxvault.module.combat;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.module.settings.EnumSetting;
import com.nyxvault.module.settings.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/**
 * AutoClicker Module - Explicit user-controlled click automation.
 * DISCLAIMER: Automated clicking may violate multiplayer server rules on HolyWorld and competitive servers.
 * Use at your own discretion.
 */
public class AutoClickerModule extends Module {
    public enum ClickButton {
        LEFT("Left Click"),
        RIGHT("Right Click");

        private final String label;
        ClickButton(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    private final EnumSetting<ClickButton> buttonSetting;
    private final NumberSetting cpsSetting;
    private final BooleanSetting jitterSetting;
    private final BooleanSetting breakBlocksSetting;

    private final Random random = new Random();
    private long lastClickTime = 0;
    private long nextInterval = 100;

    public AutoClickerModule() {
        super("AutoClicker", "User-configured legitimate click interval with timing variation", Category.UTILITIES, GLFW.GLFW_KEY_UNKNOWN);

        this.buttonSetting = new EnumSetting<>("Button", "Target mouse button", ClickButton.LEFT, ClickButton.values());
        this.cpsSetting = new NumberSetting("CPS", "Target clicks per second", 12, 1, 20);
        this.jitterSetting = new BooleanSetting("Humanize Jitter", "Random timing variance to mimic human clicks", true);
        this.breakBlocksSetting = new BooleanSetting("Hold Break Blocks", "Avoid clicking while mining blocks", true);

        addSetting(buttonSetting);
        addSetting(cpsSetting);
        addSetting(jitterSetting);
        addSetting(breakBlocksSetting);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.currentScreen != null) return;

        // Only click when user holds down the activation button in game
        KeyBinding targetKey = buttonSetting.getValue() == ClickButton.LEFT ? client.options.attackKey : client.options.useKey;
        if (!targetKey.isPressed()) return;

        // If mining blocks, respect vanilla mining
        if (breakBlocksSetting.getValue() && client.interactionManager != null && client.interactionManager.isBreakingBlock()) {
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastClickTime >= nextInterval) {
            lastClickTime = now;

            // Trigger click
            if (buttonSetting.getValue() == ClickButton.LEFT) {
                KeyBinding.onKeyPressed(client.options.attackKey.getDefaultKey());
            } else {
                KeyBinding.onKeyPressed(client.options.useKey.getDefaultKey());
            }

            // Calculate next interval with optional jitter
            int targetCPS = cpsSetting.getValue();
            long baseInterval = 1000 / targetCPS;
            if (jitterSetting.getValue()) {
                int variance = (int) (baseInterval * 0.25);
                int randomOffset = random.nextInt(Math.max(1, variance * 2)) - variance;
                nextInterval = Math.max(25, baseInterval + randomOffset);
            } else {
                nextInterval = baseInterval;
            }
        }
    }
}
