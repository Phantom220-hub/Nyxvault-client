package com.nyxvault.mixin;

import com.nyxvault.NyxVaultClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {

    @Inject(method = "render", at = @At("RETURN"))
    private void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (NyxVaultClient.getInstance() != null) {
            NyxVaultClient.getInstance().getModuleManager().onRenderHUD(context, tickCounter.getTickDelta(false));
            NyxVaultClient.getInstance().getNotificationManager().render(context);
        }
    }
}
