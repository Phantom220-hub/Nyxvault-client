package com.nyxvault.notification;

public class Notification {
    public enum Type {
        INFO(0x8b5cf6),     // Violet
        SUCCESS(0x10b981),  // Emerald
        WARNING(0xf59e0b),  // Amber
        ERROR(0xef4444);    // Crimson

        private final int color;
        Type(int color) { this.color = color; }
        public int getColor() { return color; }
    }

    private final String title;
    private final String message;
    private final Type type;
    private final long durationMs;
    private final long startTime;

    public Notification(String title, String message, Type type, long durationMs) {
        this.title = title;
        this.message = message;
        this.type = type;
        this.durationMs = durationMs;
        this.startTime = System.currentTimeMillis();
    }

    public String getTitle() { return title; }
    public String getMessage() { return message; }
    public Type getType() { return type; }
    public long getDurationMs() { return durationMs; }
    public long getStartTime() { return startTime; }

    public float getProgress() {
        long elapsed = System.currentTimeMillis() - startTime;
        return Math.min(1.0f, (float) elapsed / durationMs);
    }

    public boolean isExpired() {
        return System.currentTimeMillis() - startTime > durationMs;
    }
}
