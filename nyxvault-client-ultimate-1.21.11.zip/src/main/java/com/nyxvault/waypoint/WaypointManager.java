package com.nyxvault.waypoint;

import com.nyxvault.NyxVaultClient;
import com.nyxvault.notification.Notification;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class WaypointManager {
    private final CopyOnWriteArrayList<Waypoint> waypoints = new CopyOnWriteArrayList<>();
    private Waypoint activeWaypoint;
    private boolean globalAutoRemove = false;
    private double defaultRadius = 3.0;

    public WaypointManager() {
        // Seed default points
        waypoints.add(new Waypoint("HolyWorld Spawn", "Main hub market & portal sanctuary", 0.0, 70.0, 0.0, "minecraft:overworld", 0x8b5cf6, "HUB", "HolyWorld"));
        waypoints.add(new Waypoint("Anarchy Base Alpha", "Secure underground vault storage", 1250.0, 24.0, -840.0, "minecraft:overworld", 0x06b6d4, "VAULT", "HolyWorld"));
        waypoints.add(new Waypoint("Nether Highway Portal", "Fast transit to coordinate outpost", 156.0, 118.0, -105.0, "minecraft:the_nether", 0xf59e0b, "PORTAL", "Transport"));
    }

    public void addWaypoint(Waypoint waypoint) {
        waypoints.add(waypoint);
        if (activeWaypoint == null) {
            activeWaypoint = waypoint;
        }
        NyxVaultClient.getInstance().getConfigManager().saveConfig();
    }

    public void removeWaypoint(Waypoint waypoint) {
        waypoints.remove(waypoint);
        if (activeWaypoint == waypoint) {
            activeWaypoint = waypoints.isEmpty() ? null : waypoints.get(0);
        }
        NyxVaultClient.getInstance().getConfigManager().saveConfig();
    }

    public List<Waypoint> getWaypoints() {
        return new ArrayList<>(waypoints);
    }

    public Waypoint getActiveWaypoint() {
        return activeWaypoint;
    }

    public void setActiveWaypoint(Waypoint waypoint) {
        this.activeWaypoint = waypoint;
    }

    public boolean isGlobalAutoRemove() {
        return globalAutoRemove;
    }

    public void setGlobalAutoRemove(boolean globalAutoRemove) {
        this.globalAutoRemove = globalAutoRemove;
    }

    public double getDefaultRadius() {
        return defaultRadius;
    }

    public void setDefaultRadius(double defaultRadius) {
        this.defaultRadius = defaultRadius;
    }

    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        double px = client.player.getX();
        double py = client.player.getY();
        double pz = client.player.getZ();
        String currentDim = client.world.getRegistryKey().getValue().toString();

        List<Waypoint> toRemove = new ArrayList<>();

        for (Waypoint wp : waypoints) {
            if (!wp.isEnabled()) continue;
            if (!wp.getDimension().equals(currentDim)) continue;

            // Check if per-waypoint or global auto removal is active
            if (wp.isAutoRemove() || globalAutoRemove) {
                double radius = wp.isAutoRemove() ? wp.getArrivalRadius() : defaultRadius;
                double dist = wp.distanceTo(px, py, pz);

                if (dist <= radius) {
                    toRemove.add(wp);
                }
            }
        }

        // Process removals cleanly to prevent concurrent modification
        for (Waypoint wp : toRemove) {
            waypoints.remove(wp);
            if (activeWaypoint == wp) {
                activeWaypoint = waypoints.isEmpty() ? null : waypoints.get(0);
            }

            // Trigger notification
            NyxVaultClient.getInstance().getNotificationManager().send(new Notification(
                    "WAYPOINT REACHED",
                    "Arrived at: " + wp.getName(),
                    Notification.Type.SUCCESS,
                    4500
            ));

            // Play arrival chime
            if (client.player != null) {
                client.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
            }

            // Save persistent config
            NyxVaultClient.getInstance().getConfigManager().saveConfig();
        }
    }

    public void renderWorld(WorldRenderContext context) {
        // World renderer for waypoints, beams, and floating labels
        // In full Fabric runtime, custom vertex buffers render vertical beams
    }

    public List<Waypoint> getSortedByDistance(double px, double py, double pz) {
        List<Waypoint> sorted = new ArrayList<>(waypoints);
        sorted.sort(Comparator.comparingDouble(wp -> wp.distanceTo(px, py, pz)));
        return sorted;
    }
}
