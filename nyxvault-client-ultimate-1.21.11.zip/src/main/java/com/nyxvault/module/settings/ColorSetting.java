package com.nyxvault.module.settings;

import java.awt.Color;

public class ColorSetting extends Setting<Color> {
    public ColorSetting(String name, String description, Color defaultValue) {
        super(name, description, defaultValue);
    }

    public int getRGB() {
        return getValue().getRGB();
    }
}
