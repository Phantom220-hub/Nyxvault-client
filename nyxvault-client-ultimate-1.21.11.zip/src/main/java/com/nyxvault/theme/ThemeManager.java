package com.nyxvault.theme;

import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.Map;

public class ThemeManager {
    private final Map<String, Theme> themes = new LinkedHashMap<>();
    private Theme currentTheme;
    private Color customAccent = new Color(139, 92, 246); // Default Violet

    public ThemeManager() {
        registerThemes();
    }

    private void registerThemes() {
        // 1. NYXVAULT SIGNATURE (Deep black surfaces, midnight-blue panels, bright violet highlights, electric-purple glow, subtle cold-blue accents)
        Theme signature = new Theme(
                "NYXVAULT SIGNATURE",
                new Color(7, 7, 13, 245),      // Deep black surface #07070d
                new Color(15, 17, 36, 230),     // Midnight-blue panel #0f1124
                new Color(22, 24, 48, 220),     // Rounded card #161830
                new Color(139, 92, 246),        // Bright violet highlight #8b5cf6
                new Color(192, 132, 252, 180),  // Electric-purple glow
                new Color(248, 250, 252),       // Text primary #f8fafc
                new Color(148, 163, 184),       // Text secondary #94a3b8
                new Color(56, 189, 248, 120)    // Cold-blue illuminated border
        );

        // 2. Dark Purple
        Theme darkPurple = new Theme(
                "Dark Purple",
                new Color(10, 6, 18, 245),
                new Color(24, 14, 42, 230),
                new Color(36, 20, 64, 220),
                new Color(168, 85, 247),
                new Color(216, 180, 254, 180),
                new Color(250, 245, 255),
                new Color(192, 132, 252),
                new Color(147, 51, 234, 130)
        );

        // 3. Cyberpunk Blue
        Theme cyberpunkBlue = new Theme(
                "Cyberpunk Blue",
                new Color(6, 11, 20, 245),
                new Color(12, 24, 44, 230),
                new Color(18, 38, 70, 220),
                new Color(6, 182, 212),
                new Color(56, 189, 248, 180),
                new Color(240, 253, 250),
                new Color(125, 211, 252),
                new Color(14, 165, 233, 140)
        );

        // 4. Minimal Dark
        Theme minimalDark = new Theme(
                "Minimal Dark",
                new Color(12, 12, 12, 245),
                new Color(20, 20, 20, 230),
                new Color(30, 30, 30, 220),
                new Color(228, 228, 231),
                new Color(244, 244, 245, 120),
                new Color(255, 255, 255),
                new Color(161, 161, 170),
                new Color(63, 63, 70, 140)
        );

        themes.put(signature.getName(), signature);
        themes.put(darkPurple.getName(), darkPurple);
        themes.put(cyberpunkBlue.getName(), cyberpunkBlue);
        themes.put(minimalDark.getName(), minimalDark);

        this.currentTheme = signature;
    }

    public Map<String, Theme> getThemes() {
        return themes;
    }

    public Theme getCurrentTheme() {
        return currentTheme;
    }

    public void setTheme(String name) {
        if (themes.containsKey(name)) {
            this.currentTheme = themes.get(name);
        }
    }

    public Color getCustomAccent() {
        return customAccent;
    }

    public void setCustomAccent(Color customAccent) {
        this.customAccent = customAccent;
    }
}
