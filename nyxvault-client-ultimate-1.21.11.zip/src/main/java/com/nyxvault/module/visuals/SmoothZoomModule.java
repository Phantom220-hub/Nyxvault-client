package com.nyxvault.module.visuals;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.DecimalSetting;
import org.lwjgl.glfw.GLFW;

public class SmoothZoomModule extends Module {
    private final DecimalSetting zoomFactor;
    private double originalFov = 70.0;
    private double currentFov = 70.0;

    public SmoothZoomModule() {
        super("Smooth Zoom", "Cinematic FOV zoom with linear interpolation", Category.VISUALS, GLFW.GLFW_KEY_C);
        this.zoomFactor = new DecimalSetting("Zoom Level", "FOV division multiplier", 3.5, 2.0, 8.0, 0.5);
        addSetting(zoomFactor);
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            originalFov = mc.options.getFov().getValue();
            currentFov = originalFov;
        }
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.getFov().setValue((int) originalFov);
        }
    }

    public double getAdjustedFov() {
        return originalFov / zoomFactor.getValue();
    }
}
