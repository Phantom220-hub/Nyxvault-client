package com.nyxvault.module.combat;

import com.nyxvault.module.Category;
import com.nyxvault.module.Module;
import com.nyxvault.module.settings.BooleanSetting;
import com.nyxvault.module.settings.ColorSetting;
import com.nyxvault.module.settings.NumberSetting;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;

public class HitMarkerModule extends Module {
    private final NumberSetting durationSetting;
    private final NumberSetting sizeSetting;
    private final ColorSetting colorSetting;
    private final BooleanSetting playSoundSetting;
    private final BooleanSetting expandingRingSetting;

    private long lastHitTime = 0;

    public HitMarkerModule() {
        super("Hit Marker", "Four-segment indicator with expanding purple ring on confirmed hit", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);

        this.durationSetting = new NumberSetting("Duration (ms)", "How long marker persists", 280, 100, 600);
        this.sizeSetting = new NumberSetting("Size", "Radius of indicator segments", 8, 4, 18);
        this.colorSetting = new ColorSetting("Marker Color", "Color of reticle", new Color(168, 85, 247));
        this.playSoundSetting = new BooleanSetting("Hit Audio", "Play high-frequency audio feedback", true);
        this.expandingRingSetting = new BooleanSetting("Expanding Ring", "Render expanding energy pulse", true);

        addSetting(durationSetting);
        addSetting(sizeSetting);
        addSetting(colorSetting);
        addSetting(playSoundSetting);
        addSetting(expandingRingSetting);
    }

    public void onConfirmedHit() {
        if (!isEnabled()) return;
        this.lastHitTime = System.currentTimeMillis();
    }

    @Override
    public void onRenderHUD(DrawContext context, float tickDelta) {
        if (mc.getWindow() == null) return;

        long elapsed = System.currentTimeMillis() - lastHitTime;
        int maxDuration = durationSetting.getValue();
        if (elapsed > maxDuration) return;

        float progress = (float) elapsed / maxDuration;
        float alpha = 1.0f - progress;
        int alphaByte = (int) (alpha * 255);

        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;

        int size = sizeSetting.getValue();
        int baseColor = colorSetting.getRGB() & 0x00FFFFFF;
        int colorWithAlpha = (alphaByte << 24) | baseColor;

        // Draw 4 diagonal segments: top-left, top-right, bottom-left, bottom-right
        int gap = 3;
        // Top-left
        context.fill(cx - size, cy - size, cx - gap, cy - gap + 1, colorWithAlpha);
        // Top-right
        context.fill(cx + gap, cy - size, cx + size, cy - gap + 1, colorWithAlpha);
        // Bottom-left
        context.fill(cx - size, cy + gap, cx - gap, cy + size, colorWithAlpha);
        // Bottom-right
        context.fill(cx + gap, cy + gap, cx + size, cy + size, colorWithAlpha);

        // Optional expanding ring
        if (expandingRingSetting.getValue()) {
            int ringRadius = (int) (size + progress * 14);
            int ringColor = ((int) (alpha * 120) << 24) | 0x38BDF8; // Cold-blue glow
            context.fill(cx - ringRadius, cy - 1, cx - ringRadius + 2, cy + 1, ringColor);
            context.fill(cx + ringRadius - 2, cy - 1, cx + ringRadius, cy + 1, ringColor);
            context.fill(cx - 1, cy - ringRadius, cx + 1, cy - ringRadius + 2, ringColor);
            context.fill(cx - 1, cy + ringRadius - 2, cx + 1, cy + ringRadius, ringColor);
        }
    }
}
